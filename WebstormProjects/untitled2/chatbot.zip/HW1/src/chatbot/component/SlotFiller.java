package chatbot.component;

import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SlotFiller {

    /*
     * Task 1: Build the Slot Filler (extractSlotValues() in SlotFiller.java)
     * 
     * [Input] 
     * One user message (e.g., "What's the weather in State College?")
     * 
     * [Output]
     * A hash table that contains a set of (key, value) tuples, where the "key"
     * is the name of the slot (e.g., "location") and "value" is the extracted
     * value (e.g., "State College").
     * 
     */
    public Hashtable<String, String> extractSlotValues(String nowInputText) {
        
        //initialize the hash table. You do not need to change this line of code.
        Hashtable<String, String> result = new Hashtable<String, String>();
        
        //-------------- Modify Code Here (Assignment 1-3) Begins ---------------
        
      

        // Time extraction
        Pattern nowPattern = Pattern.compile("\\b(?:[1][0-2]|[1-9]):[0-5]\\d\\s?(?:AM|PM)\\b|\\b(?:[1-9]|1[0-2])\\s?(?:AM|PM)\\b");
        Matcher nowMatcher = nowPattern.matcher(nowInputText.trim().toUpperCase());
        while (nowMatcher.find()) {
            String nowMatchedSubstring = nowMatcher.group();
            System.out.println("Time found: " + nowMatchedSubstring);
            // adding value to the result hash table
            result.put("Time", nowMatchedSubstring);
        }
        
        // Required for "add_task" - Task Name (String)
        Pattern taskNamePattern = Pattern.compile("(?i)add a task (.+?)(?: due| at|,|\\.|$)");
        Matcher taskNameMatcher = taskNamePattern.matcher(nowInputText);
        if (taskNameMatcher.find()) {
            String taskName = taskNameMatcher.group(1).trim();
            result.put("TaskName", taskName);
        }

        // Required for "check_upcoming_tasks" - Date (Date)
        Pattern datePattern = Pattern.compile("(?i)(today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|\\b\\d{1,2}/\\d{1,2}/\\d{2,4}\\b)");
        Matcher dateMatcher = datePattern.matcher(nowInputText);
        if (dateMatcher.find()) {
            String date = dateMatcher.group().trim();
            result.put("Date", date);
        }

        // Required for "get_study_tips" - Topic (String)
        Pattern topicPattern = Pattern.compile("(?i)study tips for (.+?)(?: assignment|,|\\.|$)");
        Matcher topicMatcher = topicPattern.matcher(nowInputText);
        if (topicMatcher.find()) {
            String topic = topicMatcher.group(1).trim();
            result.put("Topic", topic);
        }

        // Required for "add_event_to_schedule" - Event Name (String) and Event Date (Date)
        Pattern eventNamePattern = Pattern.compile("(?i)add an event called (.+?)(?: on|,|\\.|$)");
        Matcher eventNameMatcher = eventNamePattern.matcher(nowInputText);
        if (eventNameMatcher.find()) {
            String eventName = eventNameMatcher.group(1).trim();
            result.put("EventName", eventName);
        }

        Pattern eventDatePattern = Pattern.compile("(?i)on (.+?)(?: at|,|\\.|$)");
        Matcher eventDateMatcher = eventDatePattern.matcher(nowInputText);
        if (eventDateMatcher.find()) {
            String eventDate = eventDateMatcher.group(1).trim();
            result.put("EventDate", eventDate);
        }

        // Required for "check_upcoming_schedule" - Date Range (Date)
        Pattern dateRangePattern = Pattern.compile("(?i)(next week|this week|next month|this month|\\b\\d{1,2}/\\d{1,2}/\\d{2,4}-\\d{1,2}/\\d{1,2}/\\d{2,4}\\b)");
        Matcher dateRangeMatcher = dateRangePattern.matcher(nowInputText);
        if (dateRangeMatcher.find()) {
            String dateRange = dateRangeMatcher.group().trim();
            result.put("DateRange", dateRange);
        }
        

        //-------------- Modify Code Here (Assignment 1-3) Ends ---------------
        
        //return the result hash table. You do not need to change this part of code.
        return result;
    }
}
